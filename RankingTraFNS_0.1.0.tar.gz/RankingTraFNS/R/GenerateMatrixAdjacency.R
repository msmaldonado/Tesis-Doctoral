#' @title GenerateMatrixAdjacency
#' @description Given matrix of Fuzzy Number calculate the adjacency matrix of each number
#' INPUT matrix of fuzzy numbers with dimension nx4 
#' OUPTUT adjacency matrix nxn  (0 or 1) compare each number
#' @param matrixFuzzy matrix which contain de Fuzzy Numbers
#' @return adjacency matrix which dimension nxn 
#' @export GenerateMatrixAdjacency
#' @examples
#' GenerateMatrixAdjacency
#' 
#' 



GenerateMatrixAdjacency <- function(matrixFuzzy ) {
  matrizAdj <- matrix(nrow = dim(matrixFuzzy)[1], ncol =  dim(matrixFuzzy)[1])#dimension nxn of quantity inicial matrix
  for (i in 1:dim(matrixFuzzy)[1]){
    for(j in 1:dim(matrixFuzzy)[1]){
      if(i== j){ #compare the same number
        matrizAdj[i,j] = 1
      }else{
        matrizAdj[i,j] = Decision(matrixFuzzy[i,], matrixFuzzy[j,]) # the complete colum that is the vector of the number
        
      }
    }
  }
  return(matrizAdj)
} 