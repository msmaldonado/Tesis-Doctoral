#' @title RecoverVectorLabel
#' @description recover a label�s vector  about the last function, SortMatrixAdjacency
#' @param vector vectors with matrix and label 
#' @param dimension numbers of labels
#' @return the label�s vector sorted.
#' @export RecoverVectorLabel 
#' @examples
#' 
#' 
#' 



RecoverVectorLabel <- function(vector, dimension){
  VectorLabelRec <- 1:dimension
  for(i in 1:dimension){
    VectorLabelRec[i] <- vector[dimension*dimension + i]
  }
  return(VectorLabelRec)
}