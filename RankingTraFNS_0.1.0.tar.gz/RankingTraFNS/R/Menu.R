#' @title menu
#' @description is the principal funtion of this package. With this function we can calculate ranking of many fuzzy numbers
#' randon number, numbers that are entered by keyboard or numbers acrros file Excel.
#' @export Menu
#' @examples
#' Menu()
#'

menu <- function(){
  if (!require('tidyverse')){
    stop("Please, install library 'tidyverse' before continuing.")
  }
  #install.packages("tidyverse")
  library(tidyverse)
  library(igraph)
  library(FuzzyNumbers)
  library(readxl)
  library(dplyr)
  cat(paste("Welcome the program,\nPress 1: If you want to generate a number of random fuzzy numbers\n"))
  cat(paste("Press 2: If you want to enter the numbers manually \n"))
  cat(paste("Press 3: If you want introduce a file .xlsx  (for example Prueba.xlsx)\n"))
  Option<-scan(n=1)
  if(Option == 1){
    #Random Number
    WorkMatrix <<- tidyCorners(generateFuzzy()) #is global

    VectorLabel <- generateLabel(dim(WorkMatrix)[1])
    rownames(WorkMatrix)<-VectorLabel
    cat(paste("The Fuzzy Numbers expresed by rows are\n"))
    print(WorkMatrix)
    testit(4)
    Result <-SortMatrixAd(WorkMatrix, VectorLabel)
    matrixRec <- RecoverMatrixAdja(Result, dim(WorkMatrix)[1])
    LabelRec <- RecoverVectorLabel(Result, dim(WorkMatrix)[1])

    cleanResult <- CleanMatrixAd(matrixRec)
    colnames(cleanResult)<-LabelRec

    MatrixDraw<- graph.adjacency(cleanResult, mode="directed", diag = FALSE) #make the graph
    plot(MatrixDraw,vertex.label.font=2,vertex.label.cex=.8,
         vertex.color=c("skyblue","tomato")[1+(LabelRec=="M")],edge.arrow.size=.4) #Draw the graph

  }

  if(Option == 2){
    cat(paste("Insert the quantity of trapezoidal fuzzy numbers to carry out the ranking"))
    amountNum<-scan(n=1)
    # if a positive number has been loaded
    if(amountNum>0){
      # Initializing the vectors for parameters as null
      a=NULL
      b=NULL
      c=NULL
      d=NULL
      VectorLabel = NULL

      cat(paste("\nPlease, insert each fuzzy number through its corners (a,b,c,d) and a label (text)\n"))
      cat(paste("\n(recall b=c if it is triangular)\n"))
      cat(paste("\n(make sure a<=b<=c<=d)\n"))

      # caption of the corners of the fuzzy numbers
      for(i in 1:amountNum){
        cat(paste("\nCorners of the trapezoidal fuzzy number",i,"are :\n"))
        num=scan(nmax =4)
        # We check that corners are correctly ordered as real numbers
        if(num[1]<= num[2] && num[2]<= num[3] && num[3] <= num[4]){
          a=c(a,num[1])#contain all a of fuzzy number
          b=c(b,num[2])
          c=c(c,num[3])
          d=c(d,num[4])
          # caption of labels
          cat(paste("Insert the label of this fuzzy number\n"))
          VectorLabel= c(VectorLabel,scan(,what = character(),1))

        }else{#there are some incorrect fuzzy number
          cat(paste("Failure: corners are incorrectly ordered. END."))
          return(0)
        }

      }
    }
    else{
      cat(paste("Failure: incorrect quantity of fuzzy numbers. END."))
      return(0)

    }
    WorkMatrix <<-  cbind(a, b, c, d)
    rownames(WorkMatrix)<-VectorLabel
    cat(paste("The Fuzzy Numbers expresed by rows are\n"))
    print(WorkMatrix)
    testit(4)

    Result <-SortMatrixAd(WorkMatrix, VectorLabel)
    matrixRec <- RecoverMatrixAdja(Result, dim(WorkMatrix)[1])
    LabelRec <- RecoverVectorLabel(Result, dim(WorkMatrix)[1])

    cleanResult <- CleanMatrixAd(matrixRec)
    colnames(cleanResult)<-LabelRec

    MatrixDraw<- graph.adjacency(cleanResult, mode="directed", diag = FALSE) #make the graph
    plot(MatrixDraw,vertex.label.font=2,vertex.label.cex=.8,
         vertex.color=c("skyblue","tomato")[1+(LabelRec=="M")],edge.arrow.size=.4) #Draw the graph
  }



  if(Option == 3){
    cat(paste("Remember each col represent corner of fuzzy numbers and the fifth col is the label\n"))
    cat(paste("Enter the name of file .xlsx"))
    name <- scan(,what = character(),1)
    fileN <- read_excel(name, sheet = 1, col_names = FALSE)
    WorkMatrix <<- matrix(nrow = dim(fileN)[1], ncol = 4) #always have 4 col
    VectorLabel <- c(0)
    VectorLabel <- 1:dim(fileN)[1]  #row dimension
    for (i in 1:dim(fileN)[1]){
      for(j in 1:dim(fileN)[2] ){
        if(j== 5){#if there are laber, they are in col five
          VectorLabel[i] = fileN[i,j]
        }else{
          WorkMatrix[i,j] = as.numeric(fileN[i,j])
        }
        #if is decimal number we use parse_double("1,5", locale = locale(decimal_mark = ","))
      }
    }


    rownames(WorkMatrix)<-VectorLabel
    cat(paste("The Fuzzy Numbers expresed by rows are\n"))
    print(WorkMatrix)
    testit(4)

    Result <-SortMatrixAd(WorkMatrix, VectorLabel)
    matrixRec <- RecoverMatrixAdja(Result, dim(WorkMatrix)[1])
    LabelRec <- RecoverVectorLabel(Result, dim(WorkMatrix)[1])

    cleanResult <- CleanMatrixAd(matrixRec)
    colnames(cleanResult)<-LabelRec

    MatrixDraw<- graph.adjacency(cleanResult, mode="directed", diag = FALSE) #make the graph
    plot(MatrixDraw,vertex.label.font=2,vertex.label.cex=.8,
         vertex.color=c("skyblue","tomato")[1+(LabelRec=="M")],edge.arrow.size=.4) #Draw the graph

  }


}
