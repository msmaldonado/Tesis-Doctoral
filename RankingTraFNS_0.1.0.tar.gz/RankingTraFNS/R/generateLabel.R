#' @title generateLabel
#' @description manually generate labels for each fuzzy numbers 
#' INPUT amount of numbers to label 
#' OUPTUT the vector with label.
#' @param quantutyNumbers amount of numbers to label 
#' @return the vector with all labels 
#' @export generateLabel
#' @examples
#' generateLabel(5)
#' 
#' 


generateLabel<- function(quantityNumbers){
  VectorLabel = NULL
  for(i in 1:quantityNumbers){
    cat(paste("Insert the label of this fuzzy number ", i))
    VectorLabel= c(VectorLabel,scan(,what = character(),1))
    
    
  }
  return(VectorLabel)
  
}