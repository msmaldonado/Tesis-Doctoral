#' @title generateFuzzy
#' @description generate amount of Fuzzy Numbers about of range numbers
#' OUTPUT Matrix nx4 with the cornes of fuzzy numbers
#' @return Matrix nx4 with the cornes of fuzzy numbers
#' @export generateFuzzy
#' @examples
#' generateFuzzy()
#' 
#' 

generateFuzzy<- function(){
  cat(paste("Insert the quantity of trapezoidal fuzzy numbers to carry out the ranking"))
  quantityNumbers<-scan(n=1)
  cat(paste("insert the range of random numbers"))
  quantityRandom<-scan(n=1)
  vec <- sample(1:quantityRandom, quantityNumbers*4, replace = TRUE)
  y<-matrix(vec,length(vec)/4,4)
  
  return(y)
}
