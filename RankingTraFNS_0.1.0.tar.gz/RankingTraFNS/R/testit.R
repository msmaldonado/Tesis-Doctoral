#' @title testit
#' @description sleep the program a number of second 
#' INPUT x that the number of second 
#' @param x second that the program will sleep
#' @export testit
#' @examples
#' testit(4)
#' 

testit <- function(x) #sleep program
  {
  p1 <- proc.time()
  Sys.sleep(x)
  proc.time() - p1 # The cpu usage should be negligible
}