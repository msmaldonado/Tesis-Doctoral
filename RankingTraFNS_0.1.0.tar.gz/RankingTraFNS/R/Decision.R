#' @title Decision
#' @description Given two trapezoidal fuzzy numbers FNa and FNb 
#' it computes the interval in which both \underline{FNa}_{\alpha} <= \underline{FNb}_{\alpha} 
#' and \overline{FNa}_{\alpha} <= \overline{FNb}_{\alpha}
#' INPUT two vectors FNa=c(a1,a2,a3,a4) and FNb=c(b1,b2,b3,b4) representing the trapezoidal fuzzy numbers.
#' OUPTUT the value TRUE, if FNa <= FNb, and FALSE, if not.
#' @param FNa vectors FNa=c(a1,a2,a3,a4)
#' @param FNb FNb=c(b1,b2,b3,b4)
#' @return boolean 
#' @export Decision
#' @examples
#' Decision(c(a1,a2,a3,a4), c(b1,b2,b3,b4))
#' 
#' 

Decision= function(FNa, FNb){
  #obtenemos las longitudes de los intervalos
  lengthAB<- LengthInterval(Interval(FNa, FNb))
  lengthBA<- LengthInterval(Interval(FNb,FNa))
  
  if(lengthAB>0  && lengthAB>=lengthBA)
    return(1)
  else if (lengthAB==0 && lengthBA == 0 && (sum(FNa)<= sum(FNb)) ) # si son vacias nos fijamos en los extremos 
    return(1)
  else
    return(0)
  
}