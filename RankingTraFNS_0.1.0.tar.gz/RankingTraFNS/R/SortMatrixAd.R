#' @title SortMatrixAd
#' @description Given matrix and Label of matrix. Sort the matrix of adjacency
#' INPUT matrix and vector of label
#' OUPTUT matrix and vector of label but sorted
#' @param matrixFuzzy matrix of Fuzzy Numbers
#' @param v_or_label vector with label of Fuzzy Numbers
#' @return the vector c(matrix,label) because we need to return some variable
#' @export SortMatrixAd
#' @examples
#'
#'
#'

SortMatrixAd <- function(matrixFuzzy, v_or_label){
  mymatriz <-GenerateMatrixAdjacency(matrixFuzzy)
  for(i in 1:(dim(mymatriz)[1] -1) ){
    vectorOnes <- rowSums(mymatriz)
    maximo <- 0
    vectorCoinci <- c(0)
    for(j in i:length(vectorOnes)){
      if(maximo < vectorOnes[j]){ # more ones more small
        maximo<- vectorOnes[j]
        posicionG <- j
        numRepet = 1
        vectorCoinci <- vectorCoinci[-(1:length(vectorCoinci))]
        vectorCoinci <- c(j)
      }else if(maximo == vectorOnes[j]){
        vectorCoinci <- c(vectorCoinci, j)
      }

    }
    if (length(vectorCoinci) == 1){
      saveNUM = matrixFuzzy[posicionG,]
      saveETI = v_or_label[posicionG]
      matrixFuzzy[posicionG,] <- matrixFuzzy [i,]
      matrixFuzzy [i,] = saveNUM


      v_or_label[posicionG] <- v_or_label[i]
      v_or_label [i] = saveETI
    }else{ # there are coincidences
      saveNUM = matrixFuzzy[posicionG,]
      saveETI = v_or_label[posicionG]
      matrixFuzzy[posicionG,] <- matrixFuzzy [i,]
      matrixFuzzy [i,] = saveNUM


      v_or_label[posicionG] <- v_or_label [i]
      v_or_label [i] = saveETI


    }

    mymatriz <-GenerateMatrixAdjacency(matrixFuzzy)
  }
  #return(mymatriz)
  return(c(mymatriz, v_or_label))

}
