#' @title tidyCorners 
#' @description tidy each row of matrix what contain Fuzzy numbers 
#' INPUT matrix of FuzzyNumbers
#' OUPTUT sorted matrix. 
#' @param oneMatriz matrix with Fuzzy Numbers 
#' @return sorted matrix
#' @export tidyCorners
#' @examples
#' tidyCorners(matrix)
#' 
#' 



tidyCorners<- function(oneMatriz){
  for(i in 1: dim(oneMatriz)[1]){
    if(is.unsorted(oneMatriz[i,])  ){
      oneMatriz[i,]<-oneMatriz[i,][order(oneMatriz[i,])]
    }
  }
  return(oneMatriz)
}