#' @title LengthInterval
#' @description Given a real closed intervals i it computes the lenght of the interval
#' INPUT a vector i=c(i1,i2) representing the extremes of the interval.
#' OUPTUT its lenght i2-i1.
#' OUTPUT the number 0 if the interval is empty.
#' @param i ector i=c(i1,i2) representing the extremes of the interval
#' @return its lenght of interval.
#' @export LengthInterval
#' @examples
#' LengthInterval(Interval(FNa, FNb))
#' 
#' 

LengthInterval= function(i){
  
  if(i[1]==-1 )
    return(0)
  else
    return(i[2]-i[1])
}