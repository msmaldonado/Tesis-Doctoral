#' @title CleanMatrixAd
#' @description cleans the ordered adjacency matrix from 1
#' INPUT Adjacency matrix
#' OUPTUT clean adjacency matrix
#' @param matrixAd adjacency matrix with many ones
#' @return clean adjacency matrix .
#' @export CleanMatrixAd
#' @examples
#' cleanMatrixAd(oneMatrix)
#'
#'


CleanMatrixAd <- function(matrixAd){
  vectorOnes <- rowSums(matrixAd)
  counter <-1
  while(counter <= dim(matrixAd)[1]-1){
    if(vectorOnes[counter]> vectorOnes[counter +1]){
      for(i in counter:dim(matrixAd)[1] ){
        if(i >= counter +2){
          matrixAd[counter,i]=0
        }

      }
      counter <- counter +1
    }
    else if(vectorOnes[counter]== vectorOnes[counter +1]){
      Repeated <-2
      for(j in counter:dim(matrixAd)){
        if(j >= counter +2){
          if(vectorOnes[counter] == vectorOnes[j]){
            Repeated<-Repeated +1
          }
        }
      }#for
      for(i in counter:dim(matrixAd)[1] ){ #move on  cols
        for(j in 0: Repeated-1){ #rows of  cycles
          if(i >= counter + Repeated && j == 0){ #first cycle
            if (i > counter + Repeated){
              matrixAd[j+ counter,i]=0
            }
          }
          else if(i >= counter + Repeated){
            matrixAd[j+counter,i]=0
          }
        }
      }
      counter <- counter + Repeated
    }
  }#while
  return(matrixAd)
}
