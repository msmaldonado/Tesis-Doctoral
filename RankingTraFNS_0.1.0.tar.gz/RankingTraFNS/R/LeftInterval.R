#' @title LeftInterval
#' @description Given two trapezoidal fuzzy numbers FNa=c(a1,a2,a3,a4) and FNb=c(b1,b2,b3,b4)
#' it computes the interval in which \underline{FNa}_{\alpha} <= \underline{FNb}_{\alpha}
#' INPUT two vectors a=c(a1,a2) and b=C(b1,b2) representing the left corners of the fuzzy numbers.
#' OUPTUT the vector c(u,v) representing the closed interval [u,v] in which the previous inequality holds.
#' OUTPUT the vector c(-1,-1) if the interval is empty.
#' @param a vectors a=c(a1,a2)
#' @param b b=C(b1,b2)
#' @return the vector c(u,v) representing the closed interval [u,v] in which the previous inequality holds.
#' @export LeftInterval
#' @examples
#' LeftInterval(c(FNa[1],FNa[2]),c(FNb[1],FNb[2]))
#' 
#' 
LeftInterval= function(a,b){
  
  a1<-a[1]
  a2<-a[2]
  b1<-b[1]
  b2<-b[2]
  
  if(a1<= b1 && a2 <= b2){
    return(c(0,1))
  }  else if(b1<a1 && b2<a2){
    
    return(c(-1,-1))
    
  }  else if(a1<=b1 && b1<=b2 && b2<= a2){
    y1<-abs(a1-b1)/(abs(a1-b1) + abs(a2-b2))
    return(c(0,y1))
  }else if(b1<=a1 && a1 <= a2 && a2<= b2){
    y1<-abs(a1-b1)/(abs(a1-b1) + abs(a2-b2))
    return(c(y1,1))
  }else{# some paremeter is wrong
    cat(paste("Something's wrong: Failure in function -LeftInterval-."))
  }
}