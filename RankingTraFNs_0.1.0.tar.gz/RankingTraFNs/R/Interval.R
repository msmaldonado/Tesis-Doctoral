#' @title Interval
#' @description Given two trapezoidal fuzzy numbers FNa and FNb it computes the interval in which 
#' both \underline{FNa}_{\alpha} <= \underline{FNb}_{\alpha} 
#' and\overline{FNa}_{\alpha} <= \overline{FNb}_{\alpha}
#' INPUT two vectors FNa=c(a1,a2,a3,a4) and FNb=c(b1,b2,b3,b4) representing the trapezoidal fuzzy numbers.
#' OUPTUT the vector c(u,v) representing the closed interval [u,v] in which the previous inequalities hold.
#' OUTPUT the vector c(-1,-1) if the interval is empty.
#' @param FNa vector FNa=c(a1,a2,a3,a4)
#' @param FNb FNb=c(b1,b2,b3,b4)
#' @return the vector c(u,v) representing the closed interval [u,v]
#' @export Interval
#' @examples
#' Interval(c(a1,a2,a3,a4), c(b1,b2,b3,b4))
#' 
#' 


Interval= function(FNa,FNb){
  return(Intersection(
    LeftInterval(c(FNa[1],FNa[2]),c(FNb[1],FNb[2])),
    RightInterval(c(FNa[3],FNa[4]),c(FNb[3],FNb[4]))
  ))
}