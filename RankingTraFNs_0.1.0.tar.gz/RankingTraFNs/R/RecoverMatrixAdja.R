#' @title RecoverMatrixAdja
#' @description recover a matrix of adjacency about the last function, SortMatrixAdjacency 
#' @param vector vector with number of matrix 
#' @param dimension of matrix 
#' @return the matrix 
#' @export RecoverMatrixAdja 
#' @examples
#' LeftInterval(c(FNa[1],FNa[2]),c(FNb[1],FNb[2]))
#' 
#' 





RecoverMatrixAdja <- function(vector, dimension){
  matrixR <-  matrix(nrow = dimension, ncol = dimension)
  for (i in 1:dimension){
    for(j in 1:dimension){
      matrixR[j,i] =as.numeric(vector[dimension*(i-1)+ j ]) 
    }
  }
  return(matrixR) 
}