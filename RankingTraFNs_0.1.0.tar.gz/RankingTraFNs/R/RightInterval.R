#' @title RightInterval
#' @description Given two trapezoidal fuzzy numbers FNa=c(a1,a2,a3,a4) and FNb=c(b1,b2,b3,b4)
#' it computes the interval in which \underline{FNa}_{\alpha} <= \underline{FNb}_{\alpha}
#' INPUT two vectors a=c(a3,a4) and b=C(b3,b4) representing the right corners of the fuzzy numbers.
#' OUPTUT the vector c(u,v) representing the closed interval [u,v] in which the previous inequality holds.
#' OUTPUT the vector c(-1,-1) if the interval is empty.
#' @param a vectors a=c(a3,a4)
#' @param b b=C(b3,b4)
#' @return the vector c(u,v) representing the closed interval [u,v] in which the previous inequality holds.
#' @export RightInterval
#' @examples
#' RightInterval(c(FNa[3],FNa[4]),c(FNb[3],FNb[4]))
#' 
#' 
RightInterval= function(a,b){
  
  a3<-a[1]
  a4<-a[2]
  b3<-b[1]
  b4<-b[2]
  
  if(a3<= b3 && a4 <= b4){
    return(c(0,1))
  }  else if(b3<a3 && b4<a4){
    
    return(c(-1,-1))
    
  }  else if(a3<=b3 && b3<=b4 && b4<= a4){
    y2<-abs(a4-b4)/(abs(a3-b3) + abs(a4-b4))
    return(c(y2,1))
    
    
  }else if(b3<=a3 && a3 <= a4 && a4<= b4){
    y2<-abs(a4-b4)/(abs(a3-b3) + abs(a4-b4))
    return(c(0,y2))
  }else{# some paremeter is wrong
    cat(paste("Something's wrong: Failure in function -RightInterval-."))
  }
  
}#' @title RightInterval
#' @description Given two trapezoidal fuzzy numbers FNa=c(a1,a2,a3,a4) and FNb=c(b1,b2,b3,b4)
#' it computes the interval in which \underline{FNa}_{\alpha} <= \underline{FNb}_{\alpha}
#' INPUT two vectors a=c(a3,a4) and b=C(b3,b4) representing the right corners of the fuzzy numbers.
#' OUPTUT the vector c(u,v) representing the closed interval [u,v] in which the previous inequality holds.
#' OUTPUT the vector c(-1,-1) if the interval is empty.
#' @param a vectors a=c(a3,a4)
#' @param b b=C(b3,b4)
#' @return the vector c(u,v) representing the closed interval [u,v] in which the previous inequality holds.
#' @export RightInterval
#' @examples
#' RightInterval(c(FNa[3],FNa[4]),c(FNb[3],FNb[4]))
#' 
#' 
RightInterval= function(a,b){
  
  a3<-a[1]
  a4<-a[2]
  b3<-b[1]
  b4<-b[2]
  
  if(a3<= b3 && a4 <= b4){
    return(c(0,1))
  }  else if(b3<a3 && b4<a4){
    
    return(c(-1,-1))
    
  }  else if(a3<=b3 && b3<=b4 && b4<= a4){
    y2<-abs(a4-b4)/(abs(a3-b3) + abs(a4-b4))
    return(c(y2,1))
    
    
  }else if(b3<=a3 && a3 <= a4 && a4<= b4){
    y2<-abs(a4-b4)/(abs(a3-b3) + abs(a4-b4))
    return(c(0,y2))
  }else{# some paremeter is wrong
    cat(paste("Something's wrong: Failure in function -RightInterval-."))
  }
  
}