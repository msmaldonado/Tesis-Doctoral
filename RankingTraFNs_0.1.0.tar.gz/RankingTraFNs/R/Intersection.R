#' @title Intersection
#' @description Given two real closed intervals i1 and i2 it computes the intersection interval
#' 
#' INPUT two vectors i1=c(alpha1,beta1) and i2=c(alpha2,beta2) representing the extremes of each interval.
#' OOUPTUT the vector c(u,v) representing the intersection of i1???i2.
#' OUTPUT the vector c(-1,-1) if the interval is empty.
#' @param i1 i1=c(alpha1,beta1) extreme of interval
#' @param i2 i2=c(alpha2,beta2) extreme of interval
#' @return the vector c(u,v) representing the intersection of i1???i2.
#' @export Intersection
#' @examples
#' Intersection(LeftInterval(c(FNa[1],FNa[2]),c(FNb[1],FNb[2])),RightInterval(c(FNa[3],FNa[4]),c(FNb[3],FNb[4]))
#' 
#' 

Intersection= function(i1,i2){
  alfa1<-i1[1]
  beta1<-i1[2]
  alfa2<-i2[1]
  beta2<-i2[2]
  
  if(alfa1 == -1 || alfa2 == -1){
    return(c(-1,-1))
  }
  else {
    if(max(alfa1,alfa2)<= min(beta1,beta2) ){
      return(c(max(alfa1,alfa2),min(beta1,beta2)))
    }else{
      return(c(-1,-1))
    }
  }
}